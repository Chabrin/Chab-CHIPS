-- ============================================================================
-- HR MODULE: MS SQL → Laravel CREATE VIEW Scripts
-- ============================================================================
-- Server:   localhost:51837
-- Database: chips
-- Purpose:  Present MSSQL data in the shape expected by the Laravel application
-- Generated: 2026-02-25
--
-- These views reshape legacy MSSQL tables into the column names and types
-- used by the Laravel HR module. They are organized by HR service area.
--
-- IMPORTANT: Views that reference other views (e.g., vw_sys_staff references
-- vw_sys_set_departments) must be created in the order listed below.
-- ============================================================================

USE chips;
GO

-- ############################################################################
-- SECTION 1: STAFF MANAGEMENT
-- ############################################################################
-- Covers: Departments, Positions, Banks, Staff Master, Next of Kin
-- Controllers: StaffController, HrSettingsController (dept/position CRUD)
-- ############################################################################

-- ----------------------------------------------------------------------------
-- 1.1  Departments
-- MSSQL: CHDEPT  →  Laravel: sys_set_departments
-- ----------------------------------------------------------------------------
IF OBJECT_ID('dbo.vw_sys_set_departments', 'V') IS NOT NULL
    DROP VIEW dbo.vw_sys_set_departments;
GO

CREATE VIEW dbo.vw_sys_set_departments AS
SELECT
    ROW_NUMBER() OVER (ORDER BY DEPTCODE)   AS id,
    GETDATE()                                AS date_time,
    DEPTNAME                                 AS department_name,
    DEPTCODE                                 AS mssql_dept_code   -- preserve original code for JOINs
FROM CHDEPT;
GO

-- ----------------------------------------------------------------------------
-- 1.2  Staff Positions / Designations
-- MSSQL: CHDESN  →  Laravel: sys_set_staff_positions
-- Note: Laravel adds basic_salary, reports_to_id, salary_account_id
--       which don't exist in MSSQL — filled with NULL.
-- ----------------------------------------------------------------------------
IF OBJECT_ID('dbo.vw_sys_set_staff_positions', 'V') IS NOT NULL
    DROP VIEW dbo.vw_sys_set_staff_positions;
GO

CREATE VIEW dbo.vw_sys_set_staff_positions AS
SELECT
    ROW_NUMBER() OVER (ORDER BY DESIGNCODE) AS id,
    GETDATE()                                AS date_time,
    DESGINNAME                               AS position_name,
    NULL                                     AS basic_salary,       -- MSSQL stores this on CHSTFF.SALBASC
    NULL                                     AS salary_account_id,
    1                                        AS current_status_id,
    NULL                                     AS reports_to_id,
    DESIGNCODE                               AS mssql_design_code   -- preserve original code for JOINs
FROM CHDESN;
GO

-- ----------------------------------------------------------------------------
-- 1.3  Banks
-- MSSQL: CHBANK  →  Laravel: sys_set_banks
-- ----------------------------------------------------------------------------
IF OBJECT_ID('dbo.vw_sys_set_banks', 'V') IS NOT NULL
    DROP VIEW dbo.vw_sys_set_banks;
GO

CREATE VIEW dbo.vw_sys_set_banks AS
SELECT
    ROW_NUMBER() OVER (ORDER BY BANKCODE)   AS id,
    GETDATE()                                AS date_time,
    BANKNAME                                 AS bank_name,
    NULL                                     AS address,
    1                                        AS current_status_id,
    BANKCODE                                 AS mssql_bank_code    -- preserve original code for JOINs
FROM CHBANK;
GO

-- ----------------------------------------------------------------------------
-- 1.3b Bank Branches
-- MSSQL: CHBBRA  →  Laravel: sys_set_banks_branches
-- Both store bank branch names linked to a parent bank.
-- CHSTFF.BANKBRAN FKs to CHBBRA.BRANCODE; Laravel sys_staff.branch_id FKs here.
-- ----------------------------------------------------------------------------
IF OBJECT_ID('dbo.vw_sys_set_banks_branches', 'V') IS NOT NULL
    DROP VIEW dbo.vw_sys_set_banks_branches;
GO

CREATE VIEW dbo.vw_sys_set_banks_branches AS
SELECT
    ROW_NUMBER() OVER (ORDER BY BANKCODE, BRANCODE) AS id,
    GETDATE()                                        AS date_time,
    BRANCODE                                         AS branch_code,
    BRANNAME                                         AS branch_name,
    bk.id                                            AS bank_id,
    1                                                AS current_status_id,
    br.BANKCODE                                      AS mssql_bank_code,
    br.BRANCODE                                      AS mssql_branch_code
FROM CHBBRA br
LEFT JOIN vw_sys_set_banks bk ON br.BANKCODE = bk.mssql_bank_code;
GO

-- ----------------------------------------------------------------------------
-- 1.4  Staff Master
-- MSSQL: CHSTFF + CHSNOK  →  Laravel: sys_staff
-- Joins to the views above for FK resolution (string code → integer id).
-- NOK is collapsed from CHSNOK (1-to-many) into a single kins_names field.
-- ----------------------------------------------------------------------------
IF OBJECT_ID('dbo.vw_sys_staff', 'V') IS NOT NULL
    DROP VIEW dbo.vw_sys_staff;
GO

CREATE VIEW dbo.vw_sys_staff AS
SELECT
    ROW_NUMBER() OVER (ORDER BY s.EMPNUMB)  AS id,
    GETDATE()                                AS date_time,
    -- Personal info
    NULL                                     AS photo,
    s.FULLNAME                               AS full_names,
    s.GENDER                                 AS gender,
    s.EMPADDR                                AS address,
    s.MOBNUM1                                AS mobile_number,
    s.WEMAIL                                 AS email_address,
    CAST(s.EMPDOB AS DATE)                   AS birth_date,
    s.NATIDNO                                AS national_id,
    NULL                                     AS passport,
    -- Bank details (FK to vw_sys_set_banks)
    b.id                                     AS bank_name,
    NULL                                     AS account_name,
    s.BANKACC                                AS account_number,
    -- Tax & statutory IDs
    s.NUMPIN                                 AS pin_number,
    s.NUMNHIF                                AS nhif_number,
    s.NUMNSSF                                AS nssf_number,
    -- Employment details
    s.APPDATE                                AS hire_date,
    d.id                                     AS department_id,     -- FK to vw_sys_set_departments
    p.id                                     AS position_id,       -- FK to vw_sys_set_staff_positions
    NULL                                     AS username,
    s.PRMSPAS                                AS system_password,
    NEWID()                                  AS uid,
    NULL                                     AS permission_group_id,
    CASE
        WHEN s.CURRSTAT = 'Active'   THEN 1
        WHEN s.CURRSTAT = 'Inactive' THEN 2
        ELSE NULL
    END                                      AS current_status_id,
    br.id                                    AS branch_id,         -- FK to vw_sys_set_banks_branches
    -- Location
    NULL                                     AS zone_id,
    NULL                                     AS zone_area_id,
    s.DISTRCT                                AS district,
    s.IDLOCAT                                AS location,
    s.IDSUBLOC                               AS sub_location,
    -- Personal details
    s.MSTATUS                                AS marital,
    s.SPOUSNAM                               AS spouse_name,
    s.PLACEOB                                AS birth_place,
    s.CITIZEN                                AS citizenship,
    s.PEMAIL                                 AS personal_email,
    NULL                                     AS disability,
    -- Next of Kin (collapsed from CHSNOK)
    nok.NOKNAM                               AS kins_names,
    -- Identifiers
    s.EMPNUMB                                AS staff_number,
    -- MSSQL-only fields preserved for reference
    s.SALBASC                                AS mssql_basic_salary,
    s.GRADE                                  AS mssql_grade,
    s.EMPTYPE                                AS mssql_emp_type,
    s.EMPSECT                                AS mssql_section
FROM CHSTFF s
LEFT JOIN vw_sys_set_departments d       ON s.DEPTCODE = d.mssql_dept_code
LEFT JOIN vw_sys_set_staff_positions p   ON s.DESIGN   = p.mssql_design_code
LEFT JOIN vw_sys_set_banks b             ON s.BANKCODE = b.mssql_bank_code
LEFT JOIN vw_sys_set_banks_branches br   ON s.BANKBRAN = br.mssql_branch_code AND s.BANKCODE = br.mssql_bank_code
OUTER APPLY (
    SELECT TOP 1 NOKNAM
    FROM CHSNOK n
    WHERE n.EMPNUMB = s.EMPNUMB
      AND n.NOKTYPE = 'Next of kin'
    ORDER BY n.NOKNAM
) nok;
GO

-- ----------------------------------------------------------------------------
-- 1.5  Next of Kin (Full Detail)
-- MSSQL: CHSNOK  →  No direct Laravel table (optional supplementary view)
-- Preserves the full 1-to-many NOK data that Laravel collapses.
-- ----------------------------------------------------------------------------
IF OBJECT_ID('dbo.vw_sys_staff_next_of_kin', 'V') IS NOT NULL
    DROP VIEW dbo.vw_sys_staff_next_of_kin;
GO

CREATE VIEW dbo.vw_sys_staff_next_of_kin AS
SELECT
    ROW_NUMBER() OVER (ORDER BY n.EMPNUMB, n.NOKTYPE) AS id,
    n.EMPNUMB       AS staff_number,
    n.NOKNAM         AS kin_name,
    n.NOKRELA        AS relationship,
    n.NOKTYPE        AS kin_type,
    n.NOKADDR        AS kin_address,
    n.NOKCITY        AS kin_city,
    n.NOKTEL         AS kin_phone
FROM CHSNOK n;
GO


-- ############################################################################
-- SECTION 2: PAYROLL CONFIGURATION
-- ############################################################################
-- Covers: Payroll Element Definitions, Tax Bands, Payroll Calendar/Periods
-- Controllers: PayrollController (elements, tax bands, calendar CRUD)
-- ############################################################################

-- ----------------------------------------------------------------------------
-- 2.1  Payroll Element Definitions
-- MSSQL: CHPREDS  →  Laravel: sys_hr_payroll_elements
-- These are the catalogue of earnings/deductions, not actual payslip values.
-- MSSQL has 24 definitions; Laravel uses same concept with different typing.
-- ----------------------------------------------------------------------------
IF OBJECT_ID('dbo.vw_sys_hr_payroll_elements', 'V') IS NOT NULL
    DROP VIEW dbo.vw_sys_hr_payroll_elements;
GO

CREATE VIEW dbo.vw_sys_hr_payroll_elements AS
SELECT
    ROW_NUMBER() OVER (ORDER BY EDCODE)  AS id,
    GETDATE()                             AS date_time,
    EDNAME                                AS element_name,
    -- Laravel element_type: 1 = Deduction, 2 = Allowance/Earning
    CASE
        WHEN EDTYPE = 'Deduction' THEN 1
        WHEN EDTYPE = 'Earning'   THEN 2
        WHEN EDTYPE = 'Saving'    THEN 1   -- Treat savings as deductions
        WHEN EDTYPE = 'Computed'  THEN 1   -- Computed items (PAYE, Net) treated as deductions
        ELSE NULL
    END                                   AS element_type,
    -- Laravel formula_id: maps MSSQL TYPECHR
    CASE
        WHEN TYPECHR = 'Fixed'             THEN 1
        WHEN TYPECHR = 'Computed'          THEN 2
        WHEN TYPECHR = 'Depends on Staff'  THEN 3
        ELSE NULL
    END                                   AS formula_id,
    EDRATE                                AS amount,
    NULL                                  AS account_id,        -- Needs GL account mapping
    NULL                                  AS staff_positions_id,
    NULL                                  AS created_by_id,     -- No MSSQL equivalent
    NULL                                  AS payslip_position,  -- No MSSQL equivalent
    -- Derive a slug key for programmatic lookups
    CASE EDNAME
        WHEN 'BASIC SALARY'   THEN 'basic_salary'
        WHEN 'NSSF'           THEN 'nssf'
        WHEN 'NHIF'           THEN 'nhif'
        WHEN 'HOUSING LEVY'   THEN 'housing_levy'
        WHEN 'PAYE'           THEN 'payee'
        WHEN 'HELB LOANS'     THEN 'helb_loans'
        WHEN 'NET SALARY'     THEN 'net_salary'
        WHEN 'SALARY ADVANCE' THEN 'salary_advance'
        ELSE LOWER(REPLACE(REPLACE(EDNAME, ' ', '_'), '-', '_'))
    END                                   AS element_key,
    5                                     AS current_status_id,
    -- MSSQL-only fields preserved
    EDCODE                                AS mssql_ed_code,
    GLACCOUNT                             AS mssql_gl_account,
    TAXABLE                               AS mssql_taxable,
    RECURR                                AS mssql_recurring,
    EDTYPE                                AS mssql_ed_type,
    TYPECHR                               AS mssql_type_chr
FROM CHPREDS;
GO

-- ----------------------------------------------------------------------------
-- 2.2  Tax Bands (PAYE Brackets)
-- MSSQL: CHPTABS  →  Laravel: um_tax_bands
-- MSSQL stores bands per year/month. This view takes the latest set.
-- Sample: Band A 0–24K @10%, Band B 24K–32K @25%, Band D 32K+ @30%
-- ----------------------------------------------------------------------------
IF OBJECT_ID('dbo.vw_um_tax_bands', 'V') IS NOT NULL
    DROP VIEW dbo.vw_um_tax_bands;
GO

CREATE VIEW dbo.vw_um_tax_bands AS
SELECT
    ROW_NUMBER() OVER (ORDER BY t.CATMIN)  AS id,
    t.CATMIN                                AS range_from,
    CASE
        WHEN t.CATMAX >= 999999999 THEN NULL
        ELSE t.CATMAX
    END                                     AS range_to,
    t.CATRAT                                AS tax_rate,
    CASE
        WHEN t.CATMAX >= 999999999 THEN 1
        ELSE 0
    END                                     AS is_last,
    'system'                                AS added_by,
    NULL                                    AS updated_by,
    GETDATE()                               AS created_at,
    NULL                                    AS updated_at,
    -- MSSQL-only fields
    t.CATEGO                                AS mssql_category,
    t.PYEAR                                 AS mssql_year,
    t.PMONTH                                AS mssql_month
FROM CHPTABS t
WHERE t.PYEAR = (SELECT MAX(PYEAR) FROM CHPTABS)
  AND t.PMONTH = (
      SELECT MAX(PMONTH)
      FROM CHPTABS
      WHERE PYEAR = (SELECT MAX(PYEAR) FROM CHPTABS)
  );
GO

-- ----------------------------------------------------------------------------
-- 2.3  Payroll Calendar (Period Headers)
-- MSSQL: CHPRDS  →  Laravel: sys_hr_payroll_calendar
-- Each CHPRDS row represents a payroll month. Laravel splits this into
-- calendar (month header) and periods (date ranges within a month).
-- ----------------------------------------------------------------------------
IF OBJECT_ID('dbo.vw_sys_hr_payroll_calendar', 'V') IS NOT NULL
    DROP VIEW dbo.vw_sys_hr_payroll_calendar;
GO

CREATE VIEW dbo.vw_sys_hr_payroll_calendar AS
SELECT
    ROW_NUMBER() OVER (ORDER BY PRYEAR, PRMNTH)  AS id,
    GETDATE()                                      AS date_time,
    -- Compose YYYYMM string matching Laravel's payroll_month_date format
    CAST(PRYEAR AS VARCHAR(4)) + RIGHT('0' + CAST(PRMNTH AS VARCHAR(2)), 2)
                                                   AS payroll_month_date,
    CASE
        WHEN PRSTATUS = 'Open'   THEN 5   -- active
        WHEN PRSTATUS = 'Closed' THEN 6   -- inactive/closed
        ELSE NULL
    END                                            AS current_status_id,
    NULL                                           AS created_by,    -- No MSSQL equivalent
    NULL                                           AS position_id,   -- Vestigial column, no MSSQL equivalent
    -- MSSQL-only fields
    PRYEAR                                         AS mssql_year,
    PRMNTH                                         AS mssql_month,
    PRSTATUS                                       AS mssql_status,
    TAXTHRS                                        AS mssql_tax_threshold,
    TAXRLF                                         AS mssql_tax_relief,
    CONAME                                         AS mssql_company_name,
    COPIN                                          AS mssql_company_pin
FROM CHPRDS;
GO

-- ----------------------------------------------------------------------------
-- 2.4  Payroll Periods (Date Ranges)
-- MSSQL: CHPRDS  →  Laravel: sys_hr_payroll_periods
-- In MSSQL each CHPRDS row IS a period; Laravel allows multiple periods
-- per calendar month. This view creates one period per calendar entry.
-- ----------------------------------------------------------------------------
IF OBJECT_ID('dbo.vw_sys_hr_payroll_periods', 'V') IS NOT NULL
    DROP VIEW dbo.vw_sys_hr_payroll_periods;
GO

CREATE VIEW dbo.vw_sys_hr_payroll_periods AS
SELECT
    ROW_NUMBER() OVER (ORDER BY p.PRYEAR, p.PRMNTH)  AS id,
    GETDATE()                                          AS date_time,
    -- Current DB column (datetime representing the payroll period)
    DATEFROMPARTS(p.PRYEAR, p.PRMNTH, 1)               AS period,
    CASE
        WHEN p.PRSTATUS = 'Open'   THEN 5
        WHEN p.PRSTATUS = 'Closed' THEN 6
        ELSE NULL
    END                                                AS current_status_id,
    -- Columns from un-run migrations (model fillable expects these)
    cal.id                                             AS calendar_id,
    1                                                  AS period_number,
    p.OPEDATE                                          AS start_date,
    p.CLSDATE                                          AS end_date
FROM CHPRDS p
CROSS APPLY (
    SELECT TOP 1 id
    FROM vw_sys_hr_payroll_calendar cal
    WHERE cal.mssql_year  = p.PRYEAR
      AND cal.mssql_month = p.PRMNTH
) cal;
GO


-- ############################################################################
-- SECTION 3: PAYROLL PROCESSING & PAYSLIPS
-- ############################################################################
-- Covers: Processed payroll results (per-employee per-period)
-- Controllers: PayrollController (processPayroll), PayslipsController
-- ############################################################################

-- ----------------------------------------------------------------------------
-- 3.1  Payroll Summary (Payslips)
-- MSSQL: CHPYSL  →  Laravel: sys_hr_payroll_summary
--
-- STRUCTURAL DIFFERENCE:
--   MSSQL:  One row per employee per element per month (normalized).
--   Laravel: One row per employee per period (denormalized),
--            with named columns for statutory items + JSON for detail.
--
-- This view pivots the normalized MSSQL data into the flat Laravel shape.
-- ----------------------------------------------------------------------------
IF OBJECT_ID('dbo.vw_sys_hr_payroll_summary', 'V') IS NOT NULL
    DROP VIEW dbo.vw_sys_hr_payroll_summary;
GO

CREATE VIEW dbo.vw_sys_hr_payroll_summary AS
SELECT
    ROW_NUMBER() OVER (ORDER BY e.EMPNUMB, e.PRYEAR, e.PRMNTH) AS id,
    GETDATE()                                                    AS date_time,
    -- Staff reference (join to vw_sys_staff for integer FK)
    staff.id                                                     AS staff_id,
    e.EMPNUMB                                                    AS staff_number_id,
    -- Period
    DATEFROMPARTS(e.PRYEAR, e.PRMNTH, 1)                         AS period,
    -- Earnings (pivoted from CHPYSL element rows)
    ISNULL(basic.EDAMT, 0)                                       AS basic_salary,
    ISNULL(sarr.EDAMT, 0)                                        AS salary_arrears,       -- EDCODE 00019
    ISNULL(actall.EDAMT, 0)                                      AS acting_allowance,     -- EDCODE 00018
    -- Statutory deductions
    ISNULL(paye.EDAMT, 0)                                        AS tax_payable,          -- EDCODE 00013
    ISNULL(nhif.EDAMT, 0)                                        AS nhif,                 -- EDCODE 00005
    ISNULL(nssf.EDAMT, 0)                                        AS nssf,                 -- EDCODE 00004
    ISNULL(socwel.EDAMT, 0)                                      AS social_welfare,       -- EDCODE 00010
    -- Other deductions
    ISNULL(akiba.EDAMT, 0)                                       AS akiba_sacco_loan,     -- EDCODE 00009
    ISNULL(sadv.EDAMT, 0)                                        AS salary_advance,       -- EDCODE 00007
    ISNULL(absent.EDAMT, 0)                                      AS absenteeism,          -- EDCODE 00015
    ISNULL(secdepo.EDAMT, 0)                                     AS security_deposit,     -- EDCODE 00017
    ISNULL(helb.EDAMT, 0)                                        AS helb_loans,           -- EDCODE 00020
    ISNULL(ahl.EDAMT, 0)                                         AS housing_levy,         -- EDCODE 00022
    ISNULL(otherded.EDAMT, 0)                                    AS other_deductions,     -- EDCODE 00012
    -- Totals
    ISNULL(totded.EDAMT, 0)                                      AS total_deductions,
    ISNULL(net.EDAMT, 0)                                         AS net_pay,              -- EDCODE 00014
    ISNULL(akibashare.EDAMT, 0)                                  AS akiba_share_contribution, -- EDCODE 00011
    -- Status & FKs
    5                                                            AS current_status_id,
    NULL                                                         AS register_id,          -- No MSSQL equivalent
    NULL                                                         AS prorated_deduction,   -- No MSSQL equivalent
    ISNULL(upleave.EDAMT, 0)                                     AS unpaid_leave,         -- EDCODE 00016
    staff.department_id                                          AS department_id,        -- From staff record
    staff.position_id                                            AS position_id,          -- From staff record
    NULL                                                         AS worked_days,          -- No MSSQL equivalent
    NULL                                                         AS guarantor_loan,       -- No MSSQL equivalent
    NULL                                                         AS emmergency_loan,      -- No MSSQL equivalent
    NULL                                                         AS period_id,            -- FK to payroll_periods
    ISNULL(neglig.EDAMT, 0)                                      AS negligence,           -- EDCODE 00024
    -- MSSQL-only
    e.PRYEAR                                                     AS mssql_year,
    e.PRMNTH                                                     AS mssql_month
FROM (
    -- Get distinct employee/period combinations
    SELECT DISTINCT EMPNUMB, PRYEAR, PRMNTH
    FROM CHPYSL
) e
-- Resolve integer staff ID + department/position
LEFT JOIN vw_sys_staff staff ON e.EMPNUMB = staff.staff_number
-- Pivot individual element rows (each LEFT JOIN resolves one payslip column)
LEFT JOIN CHPYSL basic      ON e.EMPNUMB = basic.EMPNUMB      AND e.PRYEAR = basic.PRYEAR      AND e.PRMNTH = basic.PRMNTH      AND basic.EDCODE      = '00001'  -- BASIC SALARY
LEFT JOIN CHPYSL sarr       ON e.EMPNUMB = sarr.EMPNUMB       AND e.PRYEAR = sarr.PRYEAR       AND e.PRMNTH = sarr.PRMNTH       AND sarr.EDCODE       = '00019'  -- SALARY ARREARS
LEFT JOIN CHPYSL actall     ON e.EMPNUMB = actall.EMPNUMB     AND e.PRYEAR = actall.PRYEAR     AND e.PRMNTH = actall.PRMNTH     AND actall.EDCODE     = '00018'  -- ACTING ALLOWANCE
LEFT JOIN CHPYSL nssf       ON e.EMPNUMB = nssf.EMPNUMB       AND e.PRYEAR = nssf.PRYEAR       AND e.PRMNTH = nssf.PRMNTH       AND nssf.EDCODE       = '00004'  -- NSSF
LEFT JOIN CHPYSL nhif       ON e.EMPNUMB = nhif.EMPNUMB       AND e.PRYEAR = nhif.PRYEAR       AND e.PRMNTH = nhif.PRMNTH       AND nhif.EDCODE       = '00005'  -- NHIF
LEFT JOIN CHPYSL ahl        ON e.EMPNUMB = ahl.EMPNUMB        AND e.PRYEAR = ahl.PRYEAR        AND e.PRMNTH = ahl.PRMNTH        AND ahl.EDCODE        = '00022'  -- HOUSING LEVY
LEFT JOIN CHPYSL paye       ON e.EMPNUMB = paye.EMPNUMB       AND e.PRYEAR = paye.PRYEAR       AND e.PRMNTH = paye.PRMNTH       AND paye.EDCODE       = '00013'  -- PAYE
LEFT JOIN CHPYSL helb       ON e.EMPNUMB = helb.EMPNUMB       AND e.PRYEAR = helb.PRYEAR       AND e.PRMNTH = helb.PRMNTH       AND helb.EDCODE       = '00020'  -- HELB LOANS
LEFT JOIN CHPYSL socwel     ON e.EMPNUMB = socwel.EMPNUMB     AND e.PRYEAR = socwel.PRYEAR     AND e.PRMNTH = socwel.PRMNTH     AND socwel.EDCODE     = '00010'  -- SOCIAL WELFARE
LEFT JOIN CHPYSL akiba      ON e.EMPNUMB = akiba.EMPNUMB      AND e.PRYEAR = akiba.PRYEAR      AND e.PRMNTH = akiba.PRMNTH      AND akiba.EDCODE      = '00009'  -- AKIBA SACCO LOAN
LEFT JOIN CHPYSL sadv       ON e.EMPNUMB = sadv.EMPNUMB       AND e.PRYEAR = sadv.PRYEAR       AND e.PRMNTH = sadv.PRMNTH       AND sadv.EDCODE       = '00007'  -- SALARY ADVANCE
LEFT JOIN CHPYSL absent     ON e.EMPNUMB = absent.EMPNUMB     AND e.PRYEAR = absent.PRYEAR     AND e.PRMNTH = absent.PRMNTH     AND absent.EDCODE     = '00015'  -- ABSENTEEISM
LEFT JOIN CHPYSL secdepo    ON e.EMPNUMB = secdepo.EMPNUMB    AND e.PRYEAR = secdepo.PRYEAR    AND e.PRMNTH = secdepo.PRMNTH    AND secdepo.EDCODE    = '00017'  -- SECURITY DEPOSIT
LEFT JOIN CHPYSL otherded   ON e.EMPNUMB = otherded.EMPNUMB   AND e.PRYEAR = otherded.PRYEAR   AND e.PRMNTH = otherded.PRMNTH   AND otherded.EDCODE   = '00012'  -- OTHER DEDUCTIONS
LEFT JOIN CHPYSL totded     ON e.EMPNUMB = totded.EMPNUMB     AND e.PRYEAR = totded.PRYEAR     AND e.PRMNTH = totded.PRMNTH     AND totded.EDNAME     = 'TOTAL DEDUCTIONS'
LEFT JOIN CHPYSL net        ON e.EMPNUMB = net.EMPNUMB        AND e.PRYEAR = net.PRYEAR        AND e.PRMNTH = net.PRMNTH        AND net.EDCODE        = '00014'  -- NET SALARY
LEFT JOIN CHPYSL akibashare ON e.EMPNUMB = akibashare.EMPNUMB AND e.PRYEAR = akibashare.PRYEAR AND e.PRMNTH = akibashare.PRMNTH AND akibashare.EDCODE = '00011'  -- AKIBA SHARE CONTRIBUTION
LEFT JOIN CHPYSL upleave    ON e.EMPNUMB = upleave.EMPNUMB    AND e.PRYEAR = upleave.PRYEAR    AND e.PRMNTH = upleave.PRMNTH    AND upleave.EDCODE    = '00016'  -- UNPAID LEAVE
LEFT JOIN CHPYSL neglig     ON e.EMPNUMB = neglig.EMPNUMB     AND e.PRYEAR = neglig.PRYEAR     AND e.PRMNTH = neglig.PRMNTH     AND neglig.EDCODE     = '00024'  -- LOSS DUE TO NEGLIGENCE
;
GO

-- ----------------------------------------------------------------------------
-- 3.2  Payslip Element Detail (per-employee per-period per-element)
-- MSSQL: CHPYSL raw rows  →  Feeds Laravel's payslip_elements JSON column
-- This view provides the individual element breakdown for building the JSON.
-- ----------------------------------------------------------------------------
IF OBJECT_ID('dbo.vw_sys_hr_payslip_elements', 'V') IS NOT NULL
    DROP VIEW dbo.vw_sys_hr_payslip_elements;
GO

CREATE VIEW dbo.vw_sys_hr_payslip_elements AS
SELECT
    ROW_NUMBER() OVER (ORDER BY sl.EMPNUMB, sl.PRYEAR, sl.PRMNTH, sl.EDCODE) AS id,
    sl.EMPNUMB                               AS staff_number,
    sl.PRYEAR                                AS payroll_year,
    sl.PRMNTH                                AS payroll_month,
    sl.EDCODE                                AS element_code,
    sl.EDNAME                                AS element_name,
    sl.EDTYPE                                AS element_type,     -- E=Earning, D=Deduction
    sl.EDAMT                                 AS amount,
    sl.YTD                                   AS year_to_date,
    -- Map to Laravel payroll element id
    el.id                                    AS payroll_element_id
FROM CHPYSL sl
LEFT JOIN vw_sys_hr_payroll_elements el ON sl.EDCODE = el.mssql_ed_code;
GO


-- ############################################################################
-- SECTION 4: DEDUCTIONS (HELB & LOANS)
-- ############################################################################
-- Covers: HELB loan deductions, prorated/amortized deductions
-- Controller: DeductionsController
-- ############################################################################

-- ----------------------------------------------------------------------------
-- 4.1  HELB Deductions
-- MSSQL: CHLOAN  →  Laravel: sys_helb_deductions
-- Filtered to HELB-type loans only (VENDORID or element type = HELB).
-- CHLOAN doesn't explicitly tag HELB; filter by VENDORID or loan name.
-- If no HELB-specific filter exists, all loans are presented.
-- ----------------------------------------------------------------------------
IF OBJECT_ID('dbo.vw_sys_helb_deductions', 'V') IS NOT NULL
    DROP VIEW dbo.vw_sys_helb_deductions;
GO

CREATE VIEW dbo.vw_sys_helb_deductions AS
SELECT
    ROW_NUMBER() OVER (ORDER BY l.LORDID, l.LNAMT DESC) AS id,
    GETDATE()                                             AS date_time,
    NULL                                                  AS created_by_id,         -- No MSSQL equivalent
    staff.id                                              AS staff_id,
    l.LNBALANC                                            AS loan_balance,
    l.AMTMONT                                             AS monthly_deduction,
    NULL                                                  AS start_deduction_date,  -- No MSSQL equivalent
    CASE
        WHEN l.REPSTAT = 'Active'    THEN 5
        WHEN l.REPSTAT = 'Completed' THEN 6
        ELSE NULL
    END                                                   AS current_status_id,
    -- MSSQL-only fields
    l.LORDID                                              AS mssql_staff_number,
    l.REPSTAT                                             AS mssql_status,
    l.VENDORID                                            AS mssql_vendor_id,
    l.BANKN                                               AS mssql_bank,
    l.CHEQNO                                              AS mssql_cheque_no
FROM CHLOAN l
LEFT JOIN vw_sys_staff staff ON l.LORDID = staff.staff_number;
GO

-- ----------------------------------------------------------------------------
-- 4.2  Amortized / Prorated Deductions
-- MSSQL: CHLOAN  →  Laravel: sys_hr_employee_amortized_deductions
-- Same source table as HELB; contains principal, interest, repayment info.
-- ----------------------------------------------------------------------------
IF OBJECT_ID('dbo.vw_sys_hr_employee_amortized_deductions', 'V') IS NOT NULL
    DROP VIEW dbo.vw_sys_hr_employee_amortized_deductions;
GO

CREATE VIEW dbo.vw_sys_hr_employee_amortized_deductions AS
SELECT
    ROW_NUMBER() OVER (ORDER BY l.LORDID, l.LNAMT DESC) AS id,
    GETDATE()                                             AS date_time,
    staff.id                                              AS staff_id,
    l.AMTPRINC                                            AS principal_amount,
    l.INTRATE                                             AS interest_rate,
    NULL                                                  AS deduction_date,        -- No MSSQL equivalent
    NULL                                                  AS created_by_id,         -- No MSSQL equivalent
    CASE
        WHEN l.REPSTAT = 'Active'    THEN 5
        WHEN l.REPSTAT = 'Completed' THEN 6
        ELSE NULL
    END                                                   AS current_status_id,
    l.AMTMONT                                             AS monthly_deduction,
    l.LNAMT                                               AS total_amount,
    l.AMTINTER                                            AS interest_amount,
    NULL                                                  AS repayment_months,      -- No MSSQL equivalent
    NULL                                                  AS deduction_type_id,     -- No MSSQL equivalent
    NULL                                                  AS element_id,            -- No MSSQL equivalent
    NULL                                                  AS issued_date,           -- No MSSQL equivalent
    NULL                                                  AS initial_deduction,     -- No MSSQL equivalent
    -- MSSQL-only fields
    l.LORDID                                              AS mssql_staff_number,
    l.LNBALANC                                            AS mssql_loan_balance,
    l.REPSTAT                                             AS mssql_status,
    l.VENDORID                                            AS mssql_vendor_id,
    l.BANKN                                               AS mssql_bank,
    l.CHEQNO                                              AS mssql_cheque_no
FROM CHLOAN l
LEFT JOIN vw_sys_staff staff ON l.LORDID = staff.staff_number;
GO


-- ############################################################################
-- SECTION 5: TAX REPORTING (P9A)
-- ############################################################################
-- Covers: Annual P9A tax certificate data
-- No dedicated Laravel controller — data derived from PayrollSummary
-- ############################################################################

-- ----------------------------------------------------------------------------
-- 5.1  P9A Tax Certificate Data
-- MSSQL: CHP9A  →  No direct Laravel table (derived from payroll_summary)
-- This view is useful for cross-checking or migrating historical P9A data.
-- ----------------------------------------------------------------------------
IF OBJECT_ID('dbo.vw_sys_hr_p9a', 'V') IS NOT NULL
    DROP VIEW dbo.vw_sys_hr_p9a;
GO

CREATE VIEW dbo.vw_sys_hr_p9a AS
SELECT
    ROW_NUMBER() OVER (ORDER BY p.EMPNUMB, p.PRYEAR, p.PRMNTH) AS id,
    GETDATE()                    AS date_time,
    staff.id                     AS staff_id,
    p.EMPNUMB                   AS staff_number,
    p.PRYEAR                    AS tax_year,
    p.PRMNTH                    AS tax_month,
    p.AMTA                      AS gross_pay,
    p.AMTB                      AS benefits_value,
    p.AMTD                      AS defined_contribution,    -- NSSF
    p.AMTE1                     AS owner_occupied_interest,
    p.AMTE2                     AS retirement_contribution,
    p.AMTE3                     AS other_exemptions,
    p.AMTF                      AS taxable_pay,
    p.AMTG                      AS tax_charged,
    p.AMTH                      AS personal_relief,
    p.AMTJ                      AS paye_tax
FROM CHP9A p
LEFT JOIN vw_sys_staff staff ON p.EMPNUMB = staff.staff_number;
GO


-- ############################################################################
-- SECTION 6: STATUTORY DEDUCTIONS REPORTING
-- ############################################################################
-- Covers: NSSF, SHIF/NHIF, Housing Levy summary reports
-- Controller: HrReportsController
-- These are reporting views — no separate MSSQL table, derived from CHPYSL.
-- ############################################################################

-- ----------------------------------------------------------------------------
-- 6.1  NSSF Report (per employee per month)
-- Source: CHPYSL WHERE EDCODE='00004'
-- Used by: HrReportsController::getStatutoryDeductions('nssf')
-- ----------------------------------------------------------------------------
IF OBJECT_ID('dbo.vw_rpt_statutory_nssf', 'V') IS NOT NULL
    DROP VIEW dbo.vw_rpt_statutory_nssf;
GO

CREATE VIEW dbo.vw_rpt_statutory_nssf AS
SELECT
    staff.id                     AS staff_id,
    sl.EMPNUMB                  AS staff_number,
    staff.full_names             AS staff_name,
    staff.nssf_number            AS nssf_number,
    sl.PRYEAR                   AS payroll_year,
    sl.PRMNTH                   AS payroll_month,
    sl.EDAMT                    AS nssf_amount
FROM CHPYSL sl
LEFT JOIN vw_sys_staff staff ON sl.EMPNUMB = staff.staff_number
WHERE sl.EDCODE = '00004';
GO

-- ----------------------------------------------------------------------------
-- 6.2  SHIF / NHIF Report (per employee per month)
-- Source: CHPYSL WHERE EDCODE='00005'
-- Used by: HrReportsController::getStatutoryDeductions('shif')
-- ----------------------------------------------------------------------------
IF OBJECT_ID('dbo.vw_rpt_statutory_shif', 'V') IS NOT NULL
    DROP VIEW dbo.vw_rpt_statutory_shif;
GO

CREATE VIEW dbo.vw_rpt_statutory_shif AS
SELECT
    staff.id                     AS staff_id,
    sl.EMPNUMB                  AS staff_number,
    staff.full_names             AS staff_name,
    staff.nhif_number            AS nhif_number,
    sl.PRYEAR                   AS payroll_year,
    sl.PRMNTH                   AS payroll_month,
    sl.EDAMT                    AS shif_amount
FROM CHPYSL sl
LEFT JOIN vw_sys_staff staff ON sl.EMPNUMB = staff.staff_number
WHERE sl.EDCODE = '00005';
GO

-- ----------------------------------------------------------------------------
-- 6.3  Housing Levy Report (per employee per month)
-- Source: CHPYSL WHERE EDCODE='00022'
-- Used by: HrReportsController::getStatutoryDeductions('housing_levy')
-- ----------------------------------------------------------------------------
IF OBJECT_ID('dbo.vw_rpt_statutory_housing_levy', 'V') IS NOT NULL
    DROP VIEW dbo.vw_rpt_statutory_housing_levy;
GO

CREATE VIEW dbo.vw_rpt_statutory_housing_levy AS
SELECT
    staff.id                     AS staff_id,
    sl.EMPNUMB                  AS staff_number,
    staff.full_names             AS staff_name,
    sl.PRYEAR                   AS payroll_year,
    sl.PRMNTH                   AS payroll_month,
    sl.EDAMT                    AS housing_levy_amount
FROM CHPYSL sl
LEFT JOIN vw_sys_staff staff ON sl.EMPNUMB = staff.staff_number
WHERE sl.EDCODE = '00022';
GO


-- ############################################################################
-- SECTION 7: MODULES WITH NO MSSQL EQUIVALENT
-- ############################################################################
-- The following Laravel HR modules have NO corresponding MSSQL tables.
-- No views can be created for these — they are listed for completeness:
--
--   - Employee Contracts        (sys_hr_contracts)
--   - Employee Termination      (sys_hr_employee_terminations)
--   - Discipline Tracker        (sys_hr_discipline_*)
--   - Leave Management          (sys_hr_leave_*)
--   - Zone Assignments          (sys_hr_zone_assignments)
--   - Workdays                  (sys_hr_workdays)
--   - Public Holidays           (sys_hr_public_holidays)
--   - SHIF Rates settings       (sys_hr_shif_rates)
--   - NSSF Rates settings       (sys_hr_nssf_rates)
--   - Communication Templates   (sys_hr_communication_templates)
--   - HR Communications         (sys_hr_communications)
--   - Employee Attendance       (sys_hr_employee_attendance)
--   - Workflow Approvals         (sys_workflow_approvals)
--
-- These modules are entirely new functionality in the Laravel application
-- and would need to be populated from scratch or from other data sources.
--
-- The following MSSQL tables have NO corresponding Laravel tables:
--
--   - CHBEFTS   (Electronic Funds Transfer records — 20 cols, approval workflow)
--   - CHGRDS    (Staff pay grades — GRADECODE, GRADENAME)
--   - CHEMPT    (Employee types)
--   - CHSNOK    (Next of Kin — partially mapped into sys_staff.kins_names)
--
-- ############################################################################
